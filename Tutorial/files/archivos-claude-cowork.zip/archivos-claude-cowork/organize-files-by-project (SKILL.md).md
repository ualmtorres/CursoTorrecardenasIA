---
name: organize-files-by-project
description: Use this skill whenever the user wants to clean up, organize, sort, or declutter a messy folder full of files with generic, inconsistent, or meaningless names (e.g. "documento1", "Sin título", "asd", "Copia de...", "FINAL", "definitivoOK", "(1)", "(2)"). Trigger on requests like "organiza esta carpeta", "esto es un caos", "pon orden en mis archivos", "límpiame esta carpeta", "quita los duplicados", "no sé cuál versión es la buena", or any request to restructure files by project/topic and rename them consistently — even if the user doesn't use the word "skill" or name a specific folder structure. Also trigger when the user asks to find duplicate files or figure out which version of a document is the correct/final one.
---

# Organizar una carpeta caótica por proyecto/temática

## Qué hace esta skill

Convierte una carpeta plana y caótica en una estructura organizada por proyecto o temática, con nombres de archivo consistentes, sin perder información y sin borrar nada sin permiso explícito del usuario.

## Por qué el orden de los pasos importa

Los nombres de archivo mienten. "documento1", "FINAL" o "Copia de X" no dicen nada fiable sobre el contenido real, y dos archivos con nombres parecidos pueden ser cosas completamente distintas (o al revés, dos nombres muy distintos pueden ser el mismo documento). Por eso el primer paso siempre es leer el contenido — nunca clasificar ni renombrar basándote solo en el nombre del archivo.

## Flujo de trabajo

### 1. Explorar y leer TODO

Lista recursivamente todos los archivos (incluyendo subcarpetas, por caóticas o vacías que parezcan) y lee el contenido de cada uno, no solo el nombre. Para archivos de texto/CSV esto es directo; para otros formatos (imágenes, PDFs, hojas de cálculo) extrae o describe lo que puedas para entender el tema real antes de clasificar.

### 2. Agrupar por proyecto/temática real

Basándote en el contenido (no en el nombre), identifica los proyectos o temas naturales que aparecen en la carpeta: cada tema recurrente (un proyecto, un proveedor, un trámite, un cliente...) se convierte en una carpeta de primer nivel. No fuerces una taxonomía genérica predefinida — deja que la estructura emerja de lo que realmente hay en la carpeta.

### 3. Detectar duplicados y versiones en conflicto

Compara el contenido (no el nombre) para encontrar tres tipos de situaciones, que se tratan de forma distinta:

- **Duplicados exactos**: mismo contenido, nombre distinto (p.ej. "documento1.txt" y "Copia de documento1.txt"). Es seguro descartar el sobrante.
- **Versiones que se superan entre sí**: la más nueva/completa incluye o sustituye claramente a la anterior (más campos, cifras corregidas, "v2 actualizado", un estado añadido como "vencido"). Es razonable conservar solo la más completa y descartar la anterior.
- **Conflictos genuinos sin señal clara**: dos archivos que se autodeclaran "final" o "definitivo" pero con datos que no coinciden entre sí (p.ej. dos presupuestos "FINAL" con cifras distintas, sin forma de saber cuál se usó realmente). Aquí NO hay que adivinar ni decidir por el usuario cuál es la buena — márcalo explícitamente como pendiente de confirmación y pregúntale directamente.

### 4. Proponer antes de tocar nada

Antes de mover o renombrar un solo archivo, presenta al usuario:

- La estructura de carpetas propuesta (por proyecto/temática, basada en el contenido real, no en una plantilla genérica)
- La convención de nombres que vas a aplicar (ver sección siguiente)
- Qué archivos consideras duplicados o versiones superadas y por qué, y cuáles son conflictos genuinos que necesitas que el usuario resuelva él mismo

Espera confirmación explícita antes de ejecutar nada. Esto no es opcional aunque el usuario parezca tener prisa: mover y renombrar en bloque sin mostrar antes el plan es la forma más rápida de perder la confianza de alguien que ya tiene sus archivos hechos un lío y no quiere que alguien más los desordene "a su manera".

### 5. Ejecutar de forma reversible

Una vez aprobado el plan por el usuario:

- Crea las carpetas y mueve/renombra los archivos que se conservan como versión definitiva.
- Los archivos identificados como duplicados o versiones superadas (paso 3, primeros dos casos) **no se borran todavía**: muévelos a una subcarpeta tipo `_pendiente_confirmar/` con un nombre de archivo que explique brevemente por qué se descartó cada uno, y repórtaselo al usuario en la respuesta.
- Los conflictos genuinos (paso 3, último caso) se dejan **en su sitio**, ambos, con nombres que dejen claro que están en conflicto y a la espera de que el usuario elija.
- Solo borra permanentemente cuando el usuario lo confirme explícitamente — archivo por archivo o en bloque, según cómo lo pida.
- Verifica al final que el número total de archivos coincide con el original: nada se ha perdido, solo se ha movido, renombrado, o aparcado pendiente de borrado.

### 6. Convención de nombres

Aplica este patrón salvo que el usuario pida explícitamente otra cosa:

`AAAA-MM-DD_proyecto_tipo_descripcion-breve[_vN].ext`

- **Fecha**: solo si el documento tiene una fecha asociada de forma natural (reunión, factura, informe). Si no aplica, se omite del nombre.
- **Proyecto/tema**: código corto y descriptivo derivado del contenido real, no un cajón de sastre genérico.
- **Tipo de documento**: acta, presupuesto, oferta, contrato, manual, informe, factura, notas, log, etc. — el que mejor describa qué es el archivo.
- **Descripción breve**: en minúsculas, sin tildes ni espacios, palabras separadas por guiones.
- **Versión** (`_v1`, `_v2`...) solo cuando hay un historial de versiones real y trazable — nunca dejes coexistir dos archivos con sufijos ambiguos tipo "FINAL" y "definitivoOK" sin resolver antes cuál es la vigente (ver paso 3).

Evita explícitamente estos patrones al renombrar, son la causa típica del caos original: "Sin título", "Copia de", nombres sin significado como "asd" o "prueba", "(1)"/"(2)" como único diferenciador entre archivos, y sufijos de falsa autoridad como "FINAL" o "definitivoOK" cuando en realidad hay ambigüedad sin resolver.

### 7. Resumen final

Al terminar, informa con un resumen breve: cuántos archivos se organizaron, cuántos se aparcaron como duplicados o versiones superadas (y el motivo de cada uno), y qué conflictos quedan pendientes de que el usuario decida. Evita explicaciones largas archivo por archivo salvo que el usuario las pida — lo importante es que vea claramente qué se movió y qué necesita su decisión.