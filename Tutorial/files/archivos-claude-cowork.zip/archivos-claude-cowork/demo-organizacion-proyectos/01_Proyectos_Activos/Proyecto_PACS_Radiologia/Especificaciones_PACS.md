# Especificaciones PACS Radiología
- Compatibilidad DICOM 3.0
- Almacenamiento mínimo 50 TB
- Integración con RIS existente
