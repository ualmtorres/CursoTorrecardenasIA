# Manual de usuario - Firma electrónica de recetas
1. Acceder con certificado digital
2. Seleccionar paciente
3. Firmar y enviar a farmacia
