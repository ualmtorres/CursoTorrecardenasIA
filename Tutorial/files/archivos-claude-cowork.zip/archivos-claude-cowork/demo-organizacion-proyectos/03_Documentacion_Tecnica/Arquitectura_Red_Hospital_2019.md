# Arquitectura de red del hospital (2019)
Diseño de VLANs por planta. Core Cisco Catalyst 6500.
(No refleja el cableado de UCI ni el nuevo CPD)
