# Plan DRP - actualización iniciada en 2022, sin terminar
RTO: 2 horas (objetivo nuevo, no validado)
Pendiente: sección de PACS y HIS nuevo.
