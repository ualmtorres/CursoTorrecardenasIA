# Plan de Recuperación ante Desastres (2020)
RTO: 4 horas. RPO: 1 hora.
No contempla el nuevo CPD secundario.
